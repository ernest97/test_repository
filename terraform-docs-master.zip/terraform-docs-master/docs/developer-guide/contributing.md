---
title: "Contributing"
description: "terraform-docs contributing guide"
menu:
  docs:
    parent: "developer-guide"
weight: 320
toc: false
---

Check [CONTRIBUTING.md](https://git.io/JtEzg) file on the root of our repository
for more details.
