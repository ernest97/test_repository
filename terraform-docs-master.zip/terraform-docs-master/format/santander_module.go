/*
Copyright 2021 The terraform-docs Authors.

Licensed under the MIT license (the "License"); you may not
use this file except in compliance with the License.

You may obtain a copy of the License at the LICENSE file in
the root directory of this source tree.
*/

package format

import (
	"embed"
	"fmt"
	"log"
	"sort"
	"strings"
	gotemplate "text/template"

	"github.com/terraform-docs/terraform-docs/internal/types"
	"github.com/terraform-docs/terraform-docs/print"
	"github.com/terraform-docs/terraform-docs/template"
	"github.com/terraform-docs/terraform-docs/terraform"
)

//go:embed templates/santander_module*.tmpl
var santanderModuleFS embed.FS

// santanderModule represents Santander Document format.
type santanderModule struct {
	*generator

	config   *print.Config
	template *template.Template
}

// NewSantanderDocument returns new instance of Santander Document.
func NewSantanderDocument(config *print.Config) Type {
	items := readTemplateItems(santanderModuleFS, "santander_module")

	tt := template.New(config, items...)
	tt.CustomFunc(gotemplate.FuncMap{
		"type": func(t string) string {
			result, extraline := PrintFencedCodeBlock(t, "hcl")
			if !extraline {
				result += "\n"
			}
			return result
		},
		"value": func(v string) string {
			if v == "n/a" {
				return v
			}
			result, extraline := PrintFencedCodeBlock(v, "json")
			if !extraline {
				result += "\n"
			}
			return result
		},
		"isRequired": func() bool {
			return config.Settings.Required
		},
		"GetBlockParameters":      GetBlockParameters,
		"IsSpecial":               IsSpecial,
		"GetFirstLineDescription": GetFirstLineDescription,
		"GetTableType":            GetTableType,
		"HasMultilineDescription": HasMultilineDescription,
		"ContainsBlock":           ContainsBlock,
		"GetTableName":            GetTableName,
	})

	return &santanderModule{
		generator: newGenerator(config, true),
		config:    config,
		template:  tt,
	}
}

// Generate a Terraform module as Santander document.
func (d *santanderModule) Generate(module *terraform.Module) error {
	err := d.generator.forEach(func(name string) (string, error) {
		rendered, err := d.template.Render(name, module)
		if err != nil {
			return "", err
		}
		return sanitize(rendered), nil
	})

	d.generator.funcs(withModule(module))

	return err
}

func init() {
	register(map[string]initializerFn{
		"santander module": NewSantanderDocument,
	})
}

// ============================================================================================================================
// ============================================================================================================================
// ============================================================================================================================
// ============================================================================================================================
type CustomInput struct {
	Name        string
	Type        string
	Description string
}

func HasMultilineDescription(input interface{}) bool {

	result := false

	var input_description string

	switch value := input.(type) {
	case *terraform.Input:
		input_description = string(value.Description)
	case *terraform.Output:
		input_description = string(value.Description)

	default:
		log.Panicf("The type passed to HasMultilineDescription() function must be '*terraform.Input' or '*terraform.Output'")
	}

	lines := strings.Split(strings.TrimSuffix(input_description, "\n"), "\n")

	if len(lines) > 1 {
		result = strings.HasPrefix(strings.TrimSpace(lines[1]), "*")
	}

	return result
}

func GetTableType(input interface{}) string {
	var table_type string

	switch value := input.(type) {
	case *terraform.Input:
		table_type = string(value.Type)
		table_type = fmt.Sprintf("%v%v%v", "```", table_type, "```")
	case *terraform.Output:
		output_description := string(value.Description)
		if strings.HasPrefix(strings.TrimSpace(output_description), "(") {
			table_type = output_description[strings.Index(output_description, "(")+1 : strings.Index(output_description, ")")]
			table_type = fmt.Sprintf("%v%v%v", "```", table_type, "```")
		} else {
			table_type = fmt.Sprintf("%v%v%v", "```", "-", "```")
		}

	default:
		log.Panicf("The type passed to GetTableType() function must be '*terraform.Input' or '*terraform.Output'")
	}

	return table_type
}

func GetTableName(input interface{}) string {
	var table_name string

	switch value := input.(type) {
	case *terraform.Input:
		table_name = string(value.Name)

		if IsSpecial(value) {
			table_name = fmt.Sprintf("[%v](#input_%v)", table_name, table_name)
		}
	case *terraform.Output:
		table_name = string(value.Name)

		if IsSpecial(value) {
			table_name = fmt.Sprintf("[%v](#input_%v)", table_name, table_name)
		}
	default:
		log.Panicf("The type passed to GetTableType() function must be '*terraform.Input' or '*terraform.Output'")
	}

	return table_name
}

func IsSpecial(input interface{}) bool {
	var condition bool

	switch value := input.(type) {
	case *terraform.Input:
		condition = (strings.HasPrefix(string(value.Type), "object(") ||
			strings.HasPrefix(strings.TrimSpace(string(value.Type)), "list(object(") ||
			strings.HasPrefix(string(value.Type), "any") ||
			strings.HasPrefix(string(value.Type), "map(object") ||
			strings.HasPrefix(string(value.Type), "list(any)") ||
			strings.HasPrefix(string(value.Type), "list(map") ||
			strings.HasPrefix(string(value.Type), "map(any)"))

		condition = condition && HasMultilineDescription(value)
	case *terraform.Output:
		string_description := string(value.Description)
		condition = HasMultilineDescription(value) && strings.HasPrefix(strings.TrimSpace(string_description), "(")
	default:
		log.Panicf("The type passed to IsSpecial() function must be 'terraform.Input' or 'terraform.Output'")
	}

	return condition
}

func GetBlockParameters(input interface{}) []CustomInput {

	var block_parameters []CustomInput

	var descriptions_map map[string]string
	var types_map map[string]string

	// Parse Descriptions & Types (that are included in description)
	switch value := input.(type) {
	case *terraform.Input:
		descriptions_map, types_map = parseDescriptions(string(value.Description))
	case *terraform.Output:
		descriptions_map, types_map = parseDescriptions(string(value.Description))
	default:
		log.Panicf("The type passed to GetBlockParameters() function must be 'terraform.Input' or 'terraform.Output'")
	}

	keys := make([]string, 0, len(descriptions_map))
	for k := range descriptions_map {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	for _, k := range keys {
		object_field := &CustomInput{
			Name:        k,
			Type:        types_map[k],
			Description: descriptions_map[k],
		}
		block_parameters = append(block_parameters, *object_field)
	}

	return block_parameters
}

func GetFirstLineDescription(input interface{}) string {

	var first_line_description string

	var description_field string

	get_first_line := func(description string) string {
		var first_line string
		lines := strings.Split(strings.TrimSuffix(description, "\n"), "\n")

		if len(lines) > 0 {
			first_line = lines[0]
		} else {
			first_line = description
		}

		return first_line
	}

	switch value := input.(type) {
	case *terraform.Input:
		description_field = string(value.Description)
		first_line_description = get_first_line(description_field)

	case *terraform.Output:
		description_field = string(value.Description)
		first_line_description = get_first_line(description_field)
		if strings.Index(first_line_description, "=>") > 0 {
			first_line_description = strings.TrimSpace(first_line_description[strings.Index(first_line_description, "=>")+2:])
		}
	default:
		log.Panicf("The type passed to GetFirstLineDescription() function must be 'terraform.Input' or 'terraform.Output'")
	}

	return first_line_description
}

func parseDescriptions(input_description string) (map[string]string, map[string]string) {
	descriptions_map := make(map[string]string)
	types_map := make(map[string]string)

	if HasMultilineDescription(&terraform.Input{Description: types.String(input_description)}) {
		description_arr := strings.Split(strings.TrimSuffix(input_description, "\n"), "\n")

		init := 1
		end := len(description_arr) - 1

		add_to_map := func(value string, description_map map[string]string) {
			if strings.Contains(value, "=>") {

				value_aux := strings.ReplaceAll(value, " ", "")

				var_type := "-"
				var var_key string

				var_key = strings.TrimSpace(value[strings.Index(value, "*")+1:])
				var_key = var_key[:strings.Index(var_key, " ")]

				type_aux := len(value_aux[strings.Index(value_aux, var_key)+len(var_key) : strings.Index(value_aux, "=>")])

				if type_aux > 0 {
					var_type = strings.TrimSpace(value_aux[(strings.Index(value_aux, var_key) + len(var_key) + 1) : strings.Index(value_aux, "=>")-1])
				}

				var_description := strings.TrimSpace(value[strings.Index(value, "=>")+2:])

				types_map[var_key] = fmt.Sprintf("%v%v%v", "```", var_type, "```")

				description_map[var_key] = var_description
			}
		}

		for init <= end {
			if init != end {
				values := []string{description_arr[init], description_arr[end]}

				for _, value := range values {
					add_to_map(value, descriptions_map)
				}
			} else {
				add_to_map(description_arr[init], descriptions_map)
			}

			init++
			end--
		}
	}

	return descriptions_map, types_map
}

func ContainsBlock(values interface{}) bool {
	var result bool

	switch value := values.(type) {
	case []*terraform.Input:
		for i := 0; i < len(value) && !result; i++ {
			result = IsSpecial(value[i])
		}
	case []*terraform.Output:
		for i := 0; i < len(value) && !result; i++ {
			result = IsSpecial(value[i])
		}
	default:
		log.Panicf("The type passed to ContainsBlock() function must be '*terraform.Input' or '*terraform.Output'")
	}

	return result
}
