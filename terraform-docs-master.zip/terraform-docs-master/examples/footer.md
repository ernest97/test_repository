## This is an example of a footer

It looks exactly like a header, but is placed at the end of the document