package santander

import (
	"errors"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"path/filepath"
	"sync"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
)

type SantanderTesting struct {
	Name          string                 // Name of the module that will be tested
	VarsDir       string                 // Relative Path where ALL testing *.tfvars are located
	TerraformDir  string                 // Relative Path where *.tf files are located
	Options       *terraform.Options     // Terraform Options object
	DeleteAtEnd   bool                   // Decide if you want to delete temporary files at the end of tests
	Binary        string                 // Terraform binary that will be used to execute tests
	PlanOnly      bool                   // Decide if you want to just plan the infrastructure
	Vars          map[string]interface{} // Object that contains all vars
	DefaultTmpDir string                 // Temporary full path of directory where tmp folder where created
	TmpFolder     string                 // Temporary folder created to execute the tests
}

func (santander *SantanderTesting) SetupEnv(t *testing.T, varfileName string) (string, error) {
	var output string

	if santander.TmpFolder == "" {
		err := santander.CreateTmpFolder(t)
		if err != nil {
			return "", err
		}
	}

	if varfileName != "" {
		varFile, err := santander.GetVarsFromFile(t, varfileName)
		if err != nil {
			t.Log(err)
			return "", err
		}
		santander.Vars = varFile
	}

	santander.Options = terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformBinary: santander.Binary,
		Vars:            santander.Vars,
		TerraformDir:    santander.TmpFolder,
	})

	if !santander.PlanOnly {
		output = terraform.InitAndApply(t, santander.Options)
	} else {
		santander.Options.PlanFilePath = fmt.Sprintf("%v/%v", santander.TmpFolder, "plan.out")
		output = terraform.InitAndPlanAndShow(t, santander.Options)
	}

	return output, nil
}

func (santander *SantanderTesting) CleanEnv(t *testing.T) error {

	if santander.DeleteAtEnd {
		if !santander.PlanOnly {
			terraform.Destroy(t, santander.Options)
		}

		t.Logf("\n\n========== Removing temp folder '%v' ==========\n\n", santander.TmpFolder)
		err := os.RemoveAll(santander.TmpFolder)
		if err != nil {
			return err
		}

		module_testing_dir := filepath.Join(santander.DefaultTmpDir, santander.Name)
		empty, _ := isDirEmpty(module_testing_dir)
		if empty {
			err := os.RemoveAll(module_testing_dir)
			if err != nil {
				return err
			}
		}

	}

	return nil
}

func (santander *SantanderTesting) TestTerraformBinaries(t *testing.T, terraformBinaries []string, testFile string, requiredVars map[string]interface{}) error {
	t.Log("\n\n========== Initiating binaries testing ==========\n\n")

	var err error

	if len(terraformBinaries) > 0 {
		// WaitGroup is used to wait goroutines
		var wg sync.WaitGroup
		wg.Add(len(terraformBinaries))

		addRequiredVars := func(testCaseVars map[string]interface{}, requiredVars map[string]interface{}) map[string]interface{} {
			allVars := make(map[string]interface{})
			if testCaseVars != nil {
				allVars = testCaseVars
			}

			if len(requiredVars) > 0 {
				for var_key, var_value := range requiredVars {
					allVars[var_key] = var_value
				}
			}

			return allVars
		}

		for i := 0; i < len(terraformBinaries) && err == nil; i++ {
			binary := terraformBinaries[i]

			go func() {
				// Telling WaitGroup that goroutine is completed
				defer wg.Done()

				// Initialize default environment
				testOption := santander.InitializeEnvironment(t, testFile)

				// Add the required vars to the testCase
				testOption.Vars = addRequiredVars(testOption.Vars, requiredVars)

				testOption.Binary = binary
				testOption.PlanOnly = true

				t.Run(fmt.Sprintf("%v-%v", t.Name(), binary), func(test *testing.T) {
					test.Logf("\n\n========== Testing '%v' binary - '%v' ==========\n\n", binary, testFile)
					_, err = testOption.SetupEnv(test, "")
					if err == nil {
						err = testOption.CleanEnv(test)
					}
				})
			}()
		}

		// Wait for the goroutines
		wg.Wait()

		if santander.DeleteAtEnd {
			os.RemoveAll(filepath.Join(santander.DefaultTmpDir, santander.Name, t.Name()))
		}
	}

	t.Log("\n\n========== Finishing binaries testing ==========\n\n")
	return err
}

func (santander *SantanderTesting) CreateTmpFolder(t *testing.T) error {
	testName := "testing_env"

	if santander.Name == "" {
		return errors.New("property [name] of SantanderTesting struct can not be empty")
	}

	if santander.DefaultTmpDir == "" {
		santander.DefaultTmpDir = os.TempDir()
	}

	if t.Name() != "" {
		testName = t.Name()
	}

	tmpDir := filepath.Join(santander.DefaultTmpDir, santander.Name, testName)

	_, err := os.Stat(tmpDir)

	santander.TmpFolder = tmpDir

	if os.IsNotExist(err) {
		fmt.Printf("\n\n========== Creating temp folder '%v' ==========\n\n", tmpDir)

		err = os.MkdirAll(tmpDir, 0755)
		if err != nil {
			return err
		}
	}

	files, _ := ioutil.ReadDir(santander.TerraformDir)

	for _, file := range files {

		extension := filepath.Ext(file.Name())

		if extension == ".tf" {
			input, err := ioutil.ReadFile(fmt.Sprintf("%v%v", santander.TerraformDir, file.Name()))
			if err != nil {
				return err
			}

			file_path := fmt.Sprintf("%v/%v", tmpDir, file.Name())

			if _, err := os.Stat(file_path); err == nil {
				os.Remove(file_path)
			}

			err = ioutil.WriteFile(file_path, input, 0644)
			if err != nil {
				return err
			}
		}
	}

	return nil
}

func (santander *SantanderTesting) GetVarsFromFile(t *testing.T, varsFile string) (map[string]interface{}, error) {
	var varFile map[string]interface{}
	err := terraform.GetAllVariablesFromVarFileE(t, fmt.Sprintf("%v%v", santander.VarsDir, varsFile), &varFile)
	if err != nil {
		return nil, err
	}

	return varFile, nil
}

func (santander *SantanderTesting) InitializeEnvironment(t *testing.T, varsFile string) *SantanderTesting {
	testCase := *santander

	// Get Parameters from *.tfvars
	varFile, _ := testCase.GetVarsFromFile(t, varsFile)

	testCase.Vars = varFile

	return &testCase
}

func isDirEmpty(name string) (bool, error) {
	f, err := os.Open(name)
	if err != nil {
		return false, err
	}
	defer f.Close()

	_, err = f.Readdir(1)

	if err == io.EOF {
		return true, nil
	}
	return false, err
}
