package santander

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestGetVarsFromFile(t *testing.T) {
	filename := "TestgetVarsFromFile.tfvars"
	f, err := os.Create(filename)

	if err != nil {
		log.Fatal(err)
	}

	defer os.Remove(filename)
	defer f.Close()

	f.WriteString(`cost_center = "CC-CIB"`)
	f.WriteString("\n")
	f.WriteString(`product = "IaC Unit Testing"`)
	f.WriteString("\n")
	f.WriteString(`cia = "CLL"`)

	santander := &SantanderTesting{}

	vars, err := santander.GetVarsFromFile(t, filename)
	if err != nil {
		log.Fatal(err)
	}

	assert.Equal(t, "CC-CIB", vars["cost_center"].(string))
	assert.Equal(t, "IaC Unit Testing", vars["product"].(string))
	assert.Equal(t, "CLL", vars["cia"].(string))
}

func TestInitializeEnvironment(t *testing.T) {

	santander_base := &SantanderTesting{Vars: map[string]interface{}{"test": "testing"}}

	santander_new := santander_base.InitializeEnvironment(t, "")

	// Check that the clone is correctly cloned and has not the same memory address
	assert.True(t, &santander_base != &santander_new)

	assert.True(t, santander_new.Options == nil)
	assert.Empty(t, santander_new.TmpFolder)
}

func TestCreate_tmp_folder(t *testing.T) {
	f1, err := os.Create("testing.tf")
	if err != nil {
		log.Fatal(err)
	}
	defer os.Remove("testing.tf")
	defer f1.Close()
	f2, err := os.Create("testing.tfvars")
	if err != nil {
		log.Fatal(err)
	}
	defer os.Remove("testing.tfvars")
	defer f2.Close()

	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformBinary: "terraform",
		Vars:            nil,
	})

	santander := &SantanderTesting{Name: "iac.mcl.lib.terratest-scib", Options: terraformOptions, DefaultTmpDir: os.TempDir(), TerraformDir: "./"}

	err = santander.CreateTmpFolder(t)
	if err != nil {
		log.Fatal(err)
	}

	_, err = os.Stat(santander.TmpFolder)

	// Check that temporary folder is correctly created
	assert.False(t, os.IsNotExist(err))

	// Check that *.tf files are copied to destination
	_, err = os.Stat(filepath.Join(santander.TmpFolder, "testing.tf"))
	assert.False(t, os.IsNotExist(err))

	// Check that other files that do not end with .tf are not copied
	_, err = os.Stat(filepath.Join(santander.TmpFolder, "testing.tfvars"))
	assert.True(t, os.IsNotExist(err))

	os.RemoveAll(fmt.Sprintf("%v%v", santander.DefaultTmpDir, santander.Name))
}

func TestClean_env(t *testing.T) {

	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformBinary: "terraform",
		Vars:            nil,
		TerraformDir:    os.TempDir(),
	})

	testing_folder := filepath.Join(os.TempDir(), t.Name())
	santander := &SantanderTesting{Binary: "terraform", Options: terraformOptions, TmpFolder: testing_folder, PlanOnly: true, DeleteAtEnd: true}

	err := os.Mkdir(testing_folder, 0755)
	if err != nil {
		log.Fatal(err)
	}

	// Check that the function do not return error
	assert.Nil(t, santander.CleanEnv(t))

	// Check that the function works correctly and delete folder
	_, err = os.Stat(testing_folder)
	assert.True(t, os.IsNotExist(err))
}

func TestIsDirEmpty(t *testing.T) {

	os.Mkdir(t.Name(), 0755)
	defer os.RemoveAll(t.Name())

	os.MkdirAll(filepath.Join(t.Name(), "testing"), 0755)

	isEmpty, _ := isDirEmpty(t.Name())
	assert.False(t, isEmpty)

	os.RemoveAll(filepath.Join(t.Name(), "testing"))

	isEmpty, _ = isDirEmpty(t.Name())
	assert.True(t, isEmpty)
}
